from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad

key = b"1234567890123456"
msg = input("Message: ").encode()

c = AES.new(key, AES.MODE_ECB)
enc = c.encrypt(pad(msg, 16))

print("Encrypted:", enc.hex())
print("Decrypted:", unpad(c.decrypt(enc), 16).decode())
